
import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';
import path from 'path';

dotenv.config({ path: path.resolve(process.cwd(), '.env.local') });

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';

const supabase = createClient(supabaseUrl, supabaseAnonKey);

async function checkData() {
  const { data: patenti, error: pError } = await supabase.from('patenti').select('*');
  if (pError) {
    console.error('Error fetching patenti:', pError);
  } else {
    console.log(`Found ${patenti?.length} patenti.`);
    patenti?.forEach(p => console.log(`- ${p.tipo}: ${p.nome_visualizzato}`));
  }

  const { data: clienti, error: cError } = await supabase.from('clienti').select('*');
  if (cError) {
    console.error('Error fetching clienti:', cError);
  } else {
    console.log(`Found ${clienti?.length} clienti.`);
  }
}

checkData();
