'use client';

import React, { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Loader2, Phone, Mail, BadgeCheck } from 'lucide-react';
import { Patente, TipoPatente } from '@/lib/database.types';

interface SchedaClienteFormProps {
  clienteId?: string;    // undefined → nuovo cliente
  defaultValues?: {
    nome: string;
    cognome: string;
    telefono: string;
    email: string;
    patente_richiesta_id: string | null;
    preferenza_cambio: string | null;
  };
  patenti: Patente[];
  onSuccess: (id: string) => void;
  onCancel?: () => void;
}

const INPUT_CLS =
  'w-full bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl py-2.5 px-4 outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-sm';

const LABEL_CLS = 'text-xs font-semibold text-zinc-500 dark:text-zinc-400 uppercase tracking-wide';

export const SchedaClienteForm = ({
  clienteId,
  defaultValues,
  patenti,
  onSuccess,
  onCancel,
}: SchedaClienteFormProps) => {
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    nome:                 defaultValues?.nome ?? '',
    cognome:              defaultValues?.cognome ?? '',
    telefono:             defaultValues?.telefono ?? '',
    email:                defaultValues?.email ?? '',
    patente_richiesta_id: defaultValues?.patente_richiesta_id ?? '',
    preferenza_cambio:    defaultValues?.preferenza_cambio ?? '',
  });

  const set = (key: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setForm(prev => ({ ...prev, [key]: e.target.value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const payload = {
      nome:                 form.nome,
      cognome:              form.cognome,
      telefono:             form.telefono || null,
      email:                form.email || null,
      patente_richiesta_id: form.patente_richiesta_id || null,
      preferenza_cambio:    form.preferenza_cambio || null,
    };

    let id = clienteId;

    if (clienteId) {
      const { error } = await supabase
        .from('clienti')
        .update(payload)
        .eq('id', clienteId);

      if (error) { alert(error.message); setLoading(false); return; }
    } else {
      const { data, error } = await supabase
        .from('clienti')
        .insert(payload)
        .select('id')
        .single();

      if (error || !data) { alert(error?.message ?? 'Errore'); setLoading(false); return; }
      id = data.id;
    }

    setLoading(false);
    onSuccess(id!);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {/* Nome & Cognome */}
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-1.5">
          <label className={LABEL_CLS}>Nome</label>
          <input required value={form.nome} onChange={set('nome')} className={INPUT_CLS} placeholder="Mario" />
        </div>
        <div className="space-y-1.5">
          <label className={LABEL_CLS}>Cognome</label>
          <input required value={form.cognome} onChange={set('cognome')} className={INPUT_CLS} placeholder="Rossi" />
        </div>
      </div>

      {/* Telefono — con link tel: visualizzato accanto */}
      <div className="space-y-1.5">
        <label className={LABEL_CLS}>Telefono</label>
        <div className="flex items-center gap-2">
          <input
            value={form.telefono}
            onChange={set('telefono')}
            className={INPUT_CLS}
            placeholder="333 1234567"
            type="tel"
          />
          {form.telefono && (
            <a
              href={`tel:${form.telefono.replace(/\s/g, '')}`}
              className="shrink-0 flex items-center gap-1.5 px-3 py-2.5 bg-green-50 dark:bg-green-900/20 text-green-600 dark:text-green-400 rounded-xl text-sm font-semibold hover:bg-green-100 dark:hover:bg-green-900/40 transition-colors"
              title="Chiama"
            >
              <Phone size={15} />
              Chiama
            </a>
          )}
        </div>
      </div>

      {/* Email — con link mailto: visualizzato accanto */}
      <div className="space-y-1.5">
        <label className={LABEL_CLS}>Email</label>
        <div className="flex items-center gap-2">
          <input
            value={form.email}
            onChange={set('email')}
            className={INPUT_CLS}
            placeholder="mario.rossi@email.it"
            type="email"
          />
          {form.email && (
            <a
              href={`mailto:${form.email}`}
              className="shrink-0 flex items-center gap-1.5 px-3 py-2.5 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-xl text-sm font-semibold hover:bg-blue-100 dark:hover:bg-blue-900/40 transition-colors"
              title="Invia email"
            >
              <Mail size={15} />
              Email
            </a>
          )}
        </div>
      </div>

      {/* Patente richiesta & Preferenza Cambio */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-1.5">
          <label className={LABEL_CLS}>Patente Richiesta</label>
          <div className="flex items-center gap-2">
            <BadgeCheck size={18} className="text-blue-500 shrink-0" />
            <select
              value={form.patente_richiesta_id}
              onChange={set('patente_richiesta_id')}
              className={INPUT_CLS}
            >
              <option value="">— Nessuna —</option>
              {patenti.map(p => (
                <option key={p.id} value={p.id}>
                  {p.tipo} — {p.nome_visualizzato}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="space-y-1.5">
          <label className={LABEL_CLS}>Tipo Cambio</label>
          <select
            value={form.preferenza_cambio}
            onChange={set('preferenza_cambio')}
            className={INPUT_CLS}
          >
            <option value="">— Indifferente —</option>
            <option value="manuale">Manuale</option>
            <option value="automatico">Automatico</option>
          </select>
        </div>
      </div>

      {/* Actions */}
      <div className="flex gap-3 pt-2">
        {onCancel && (
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 py-3 rounded-xl font-semibold text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-all text-sm"
          >
            Annulla
          </button>
        )}
        <button
          disabled={loading}
          type="submit"
          className="flex-1 py-3 rounded-xl font-semibold bg-purple-600 text-white shadow-lg shadow-purple-500/20 hover:bg-purple-700 transition-all flex items-center justify-center text-sm"
        >
          {loading ? <Loader2 className="animate-spin" size={18} /> : clienteId ? 'Salva modifiche' : 'Crea Cliente'}
        </button>
      </div>
    </form>
  );
};
