'use client';

import React, { useEffect, useState } from 'react';
import { Plus, ChevronRight, Clock, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Appointment } from '@/types';
import { cn } from '@/lib/utils';
import { Modal } from '@/components/Modal';
import { AppointmentForm } from '@/components/forms/AppointmentForm';

export default function Home() {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const todayStr = new Date().toISOString().split('T')[0];
  const todayLabel = new Date().toLocaleDateString('it-IT', { 
    weekday: 'long', 
    day: 'numeric', 
    month: 'long' 
  });

  const fetchAppointments = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('appointments')
        .select('*, trainers(name, color)')
        .eq('appointment_date', todayStr)
        .order('appointment_time');
      
      if (error) throw error;
      setAppointments(data || []);
    } catch (error) {
      console.error('Error fetching appointments:', error);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchAppointments();
  }, [todayStr]);

  const handleSuccess = () => {
    setIsModalOpen(false);
    fetchAppointments();
  };

  return (
    <div className="p-6 md:p-10 max-w-4xl mx-auto animate-fade-in">
      <header className="mb-10 flex justify-between items-end">
        <div>
          <h1 className="text-4xl font-bold tracking-tight text-zinc-900 dark:text-zinc-50">Agenda</h1>
          <p className="text-zinc-500 dark:text-zinc-400 mt-1 capitalize">{todayLabel}</p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="bg-blue-600 p-3 rounded-2xl text-white shadow-lg shadow-blue-500/20 hover:scale-105 active:scale-95 transition-all"
        >
          <Plus size={24} />
        </button>
      </header>

      <section className="space-y-6">
        <h2 className="text-xl font-semibold px-1">Oggi</h2>
        
        {loading ? (
          <div className="p-20 flex flex-col items-center justify-center gap-4 text-zinc-400">
            <Loader2 className="animate-spin" size={40} />
            <p>Caricamento appuntamenti...</p>
          </div>
        ) : appointments.length > 0 ? (
          <div className="grid gap-4">
            {appointments.map((apt) => (
              <div key={apt.id} className="glass-card p-5 group cursor-pointer hover:border-blue-500/50">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={cn(
                      "w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-inner",
                      apt.is_unavailability ? "bg-zinc-400" : "bg-blue-500"
                    )} style={apt.trainers?.color ? { backgroundColor: apt.trainers.color } : {}}>
                      <Clock size={20} />
                    </div>
                    <div>
                      <h3 className="font-bold text-lg">{apt.client_name}</h3>
                      <div className="flex items-center gap-2 text-sm text-zinc-500 dark:text-zinc-400">
                        <span>{apt.appointment_time.slice(0, 5)}</span>
                        <span>•</span>
                        <span>{apt.trainers?.name || 'Istruttore'}</span>
                        <span>•</span>
                        <span className="px-2 py-0.5 bg-zinc-100 dark:bg-zinc-800 rounded-lg text-[10px] font-bold uppercase tracking-wider">
                          {apt.license_type}
                        </span>
                      </div>
                    </div>
                  </div>
                  <ChevronRight size={20} className="text-zinc-300 group-hover:text-blue-500 transition-colors" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="glass-card p-10 text-center text-zinc-400">
            Nessun appuntamento per oggi.
          </div>
        )}
      </section>

      {/* Modal Nuovo Appuntamento */}
      <Modal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        title="Nuovo Appuntamento"
      >
        <AppointmentForm onSuccess={handleSuccess} onCancel={() => setIsModalOpen(false)} />
      </Modal>
    </div>
  );
}
